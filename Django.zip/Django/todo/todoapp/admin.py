from typing import Any
from django.contrib import admin
from todoapp.models import Product
# Register your models here.
# admin.site.register(Product)

#defining customer filter

from django.db.models import Q
class MyPriceFilter(admin.SimpleListFilter):
	title="price"
	parameter_name="By Price"
	def lookups(self, request, model_admin):
		return (("greater","Price>5000"),("lesser","Price<5000"))
	def queryset(self,request,queryset):
		if self.value()=="greater":
			q1=Q(price__gt=5000)
			q2=Q(is_deleted="N")
			return queryset.filter(q1 & q2)
		elif self.value()=="lesser":
			return queryset.filter(price__lt=5000)
			
		else:
			return queryset.all()
			
	
		
class ProductAdmin(admin.ModelAdmin):
    list_display=["name","pdesc","price","is_deleted"]
    list_filter=["is_deleted","cat",MyPriceFilter]
admin.site.register(Product,ProductAdmin)

