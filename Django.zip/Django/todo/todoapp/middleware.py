'''
def middlewarename(get_response):
     #this isoptional--
     need to write code which u want only 1 time to be executed. for eg initializtion or configurationof middlware

     def your_function(request):
        code to be executed before view func is called.
        var=get_response(request)
        code to be executed after view func is called.

        return response

     return your_function

this is a gneric structure for which we will write a code.

'''
'''
def todo_middleware(get_response):
    print("code to be executed only once for initialization.Thi o/p we will see on terminal")
    def todo_function(request):
        print("code to be executed before view func is called.")
        res=get_response(request)
        print("code to be executed after view func is called.")
        return res
    return todo_function
'''



class todo_middleware:
    def __init__(self,get_response):
        self.get_response=get_response
        print("class based middleware code to be executed only once for initialization.Thi o/p we will see on terminal")

    def __call__(self,request):
        print("code to be executed before view func is called.")
        res=self.get_response(request)
        print("code to be executed after view func is called.")
        return res