function greet(){
    alert("Javascript file is linked properly");
}


